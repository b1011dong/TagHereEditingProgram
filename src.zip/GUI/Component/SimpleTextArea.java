package GUI.Component;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import Resource.DimenR;

public class SimpleTextArea extends JTextArea {
	
	private Font font = new Font("���� ����", Font.PLAIN, DimenR.BIG_FONT);
	private Font font2 = new Font("���� ����", Font.PLAIN, DimenR.SMALL_FONT);

	private Color fontColor = new Color(120, 120, 120);
	private Color fontColor2 = new Color(150, 150, 150);

	public SimpleTextArea() {
		super();
		customConstructor();
		setBigFont();
	}
	
	public SimpleTextArea(String text) {
		super(text);
		customConstructor();
		this.setEditable(false);
		setBigFont();
	}
	
	public SimpleTextArea(String text, String text2) {
		super(text + "\n" + text2);
		
		this.setMargin(new Insets(5, 5, 5, 5));
		this.setLineWrap(true);
		
		this.setEditable(false);
		setSmallFont();
	}
	
	public void customConstructor() {
		this.setMargin(new Insets(12, 12, 12, 12));
		this.setLineWrap(true);
	}

	public void setBigFont() {
		this.setFont(font);
		this.setForeground(fontColor);
	}
	
	public void setSmallFont() {
		this.setFont(font2);
		this.setForeground(fontColor2);
	}
}
